
package ClassesGetSet;

/**
 *
 * @author Günther
 */
public class AlunoCursoGetSet {
    //declara variavel
    
    int matricula;
    int cod_curso;
    int sala_id;
    
      public AlunoCursoGetSet(){}  
       public AlunoCursoGetSet(int matricula,  int cod_curso){
           this.matricula = matricula;
           this.cod_curso = cod_curso;
       }
       
       
    //declara get e set das variaveis para chamar elas em outras classes

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getCod_curso() {
        return cod_curso;
    }

    public void setCod_curso(int cod_curso) {
        this.cod_curso = cod_curso;
    }

    public int getSala_id() {
        return sala_id;
    }

    public void setSala_id(int sala_id) {
        this.sala_id = sala_id;
    }
    
    
}
