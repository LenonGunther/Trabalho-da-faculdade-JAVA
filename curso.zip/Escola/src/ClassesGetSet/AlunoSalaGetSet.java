
package ClassesGetSet;

/**
 *
 * @author Günther
 */
public class AlunoSalaGetSet {
    
    
    int matricula;
    int sala_id;  
    
      public AlunoSalaGetSet(){}  
       public AlunoSalaGetSet(int matricula,  int sala_id){
           this.matricula = matricula;
           this.sala_id = sala_id;
       }
       
       public AlunoSalaGetSet(int sala_id){
           this.sala_id = sala_id;
       }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getSala_id() {
        return sala_id;
    }

    public void setSala_id(int sala_id) {
        this.sala_id = sala_id;
    }

}
