package ClassesGetSet;

/**
 *
 * @author Günther
 */
public class CursoGetSet {
    //Declara as mesmas variaveis do banco de dados "curso" na classe "curso" java    
    
    int cod_curso;
    String nome_curso;
    String carga_horaria;
    String desc_curso;
    int cod_funcionario;
    int sala_id;
    
    //declarando variaveis para listar professor, curso e aluno ativos
    String professor; //nome do professor
    String curso; //nome do curso
    String aluno; //nome do aluno
    
     public CursoGetSet(){}      
       public CursoGetSet(int cod_curso, String nome_curso, String carga_horaria, String desc_curso, int cod_funcionario, int sala_id){ 
           this.cod_curso = cod_curso;
           this.nome_curso = nome_curso;
           this.carga_horaria = carga_horaria;
           this.desc_curso = desc_curso;
           this.cod_funcionario = cod_funcionario;
           this.sala_id = sala_id;
       }       
       
       public CursoGetSet(String nome_curso, String carga_horaria, String desc_curso){
           this.nome_curso = nome_curso;
           this.carga_horaria = carga_horaria;
           this.desc_curso = desc_curso;
           
       }
       
           
    //Get pega o nome da variavel e Set define a variavel

    public int getCod_curso() {
        return cod_curso;
    }

    public void setCod_curso(int cod_curso) {
        this.cod_curso = cod_curso;
    }

    public String getNome_curso() {
        return nome_curso;
    }

    public void setNome_curso(String nome_curso) {
        this.nome_curso = nome_curso;
    }

    public String getCarga_horaria() {
        return carga_horaria;
    }

    public void setCarga_horaria(String carga_horaria) {
        this.carga_horaria = carga_horaria;
    }

    public String getDesc_curso() {
        return desc_curso;
    }

    public void setDesc_curso(String desc_curso) {
        this.desc_curso = desc_curso;
    }

    public int getCod_funcionario() {
        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario) {
        this.cod_funcionario = cod_funcionario;
    }

    public int getSala_id() {
        return sala_id;
    }

    public void setSala_id(int sala_id) {
        this.sala_id = sala_id;
    }
}
