
package ClassesGetSet;

public class ProfessorCursoAluno {
    //declarando variaveis para listar professor, curso e aluno ativos
    String professor; //nome do professor
    String curso; //nome do curso
    String aluno; //nome do aluno
    
    public ProfessorCursoAluno(){}
    public ProfessorCursoAluno(String professor, String curso, String aluno){
           this.professor = professor;
           this.curso = curso;
           this.aluno = aluno;
           
       }
    
    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }
    
    
}
