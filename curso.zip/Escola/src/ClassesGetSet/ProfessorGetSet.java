package ClassesGetSet;


/**
 *
 * @author Günther
 */
public class ProfessorGetSet {
    //Declara as mesmas variaveis do banco de dados "professor" na classe "professor" java    
    
    int cod_funcionario;
    String cpf;
    String nome_completo;
    String cidade;
    String bairro;
    String rua;
    String email;
    String celular;
    
     public ProfessorGetSet(){}      
       public ProfessorGetSet(String cpf, String nome_completo, String cidade, String bairro, String rua, String email, String celular){ 
           this.cpf = cpf;
           this.nome_completo = nome_completo;
           this.cidade = cidade;
           this.bairro = bairro;
           this.rua = rua;
           this.email = email;
           this.celular = celular;
       }       
       
       public ProfessorGetSet( int cod_funcionario, String cpf, String nome_completo,String cidade, String bairro, String rua, String email, String celular){
           this.cod_funcionario = cod_funcionario;
           this.cpf = cpf;
           this.nome_completo = nome_completo;
           this.cidade = cidade;
           this.bairro = bairro;
           this.rua = rua;
           this.email = email;
           this.celular = celular;
       }
    
    //Get pega o nome da variavel e Set define a variavel

    public int getCod_funcionario() {
        return cod_funcionario;
    }

    public void setCod_funcionario(int cod_funcionario) {
        this.cod_funcionario = cod_funcionario;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome_completo() {
        return nome_completo;
    }

    public void setNome_completo(String nome_completo) {
        this.nome_completo = nome_completo;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

}