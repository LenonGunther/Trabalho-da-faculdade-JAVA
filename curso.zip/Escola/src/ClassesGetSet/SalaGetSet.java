package ClassesGetSet;

/**
 *
 * @author Günther
 */
public class SalaGetSet {
      /*Declara as mesmas variaveis do banco de dados "sala" na classe "sala" java    
    */
    int sala_id;
    String nome;
    String local;
    int cap_total;
    
    
       public SalaGetSet(){}      
       public SalaGetSet(String nome, String local, int cap_total){ 
           this.nome = nome;
           this.local = local;
           this.cap_total = cap_total;
       }       
       
       public SalaGetSet(int sala_id, String nome, String local, int cap_total){
           this.sala_id = sala_id;
           this.nome = nome;
           this.local = local;
           this.cap_total = cap_total;

       }
    
    //Get pega o nome da variavel e Set define a variavel
    
    public int getSala_id() {
        return sala_id;
    }
    
    public void setSala_id(int sala_id) {
        this.sala_id = sala_id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public int getCap_total() {
        return cap_total;
    }

    public void setCap_total(int cap_total) {
        this.cap_total = cap_total;
    }
    
}
