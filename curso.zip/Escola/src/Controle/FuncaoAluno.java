package Controle;


import javax.swing.JOptionPane;
import java.util.ArrayList;
import SQLDAOS.AlunoSQL;
import ClassesGetSet.AlunoGetSet;

public class FuncaoAluno{
    
    //metodo para listar alunos num quadro 
    public static void listar(ArrayList<AlunoGetSet> Quadro) {
        try {
            AlunoSQL x = new AlunoSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de aluno no quadro do aluno \n";//vai listar os aluno na tabela aluno
        int tamanho = Quadro.size();
        //Aluno fun = new AlunoGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo no quadro
                msg = msg + "Posição: " + i;
                msg = msg + "\nMatricula: "+ Quadro.get(i).getMatricula();
                msg = msg + "\nCpf: " + Quadro.get(i).getCpf();
                msg = msg + "\nNome_completo: " + Quadro.get(i).getNome_completo();
                msg = msg + "\ncidade: " + Quadro.get(i).getCidade();
                msg = msg + "\nBairro: " + Quadro.get(i).getBairro();
                msg = msg + "\nRua: " + Quadro.get(i).getRua();
                msg = msg + "\nEmail: " + Quadro.get(i).getEmail();
                msg = msg + "\nCelular: " + Quadro.get(i).getCelular();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
    //metodo para inserir aluno no banco de dados
    public static void inserir() {

        AlunoGetSet fun = new AlunoGetSet();
        
        //vai pedir parar que o usuario insira todos os requisitos abaixo
        fun.setCpf(JOptionPane.showInputDialog("Digite o Cpf"));
        fun.setNome_completo(JOptionPane.showInputDialog("Digite o Nome completo"));
        fun.setCidade(JOptionPane.showInputDialog("Digite a cidade"));
        fun.setBairro(JOptionPane.showInputDialog("Digite o Bairro"));
        fun.setRua(JOptionPane.showInputDialog("Digite o nome da rua e numero da casa/ap"));
        fun.setEmail(JOptionPane.showInputDialog("Digite o Email"));
        fun.setCelular(JOptionPane.showInputDialog("Digite o Celular"));
        
        AlunoSQL pdao = new AlunoSQL();
        
        pdao.inserir(fun);
    }
    
    
    //Metodo para alterar alguma coluna do banco de dados com a matricula indicada pelo usuario
    public static void atualizar () {
        AlunoGetSet fun = new AlunoGetSet();
        AlunoSQL pdao = new AlunoSQL();
        int id;
        
        id = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero da matricula do Aluno para alterar"));//vai pedir a matricula para localizar e atualizar 
        fun = pdao.procura(id);
        if (fun != null) {
            //usuario vai poder atualizar qualquer requisito abaixo
            fun.setMatricula(id);
            fun.setCpf(JOptionPane.showInputDialog(null, "Digite o Cpf", fun.getCpf()));
            fun.setNome_completo(JOptionPane.showInputDialog(null, "Digite o Nome_completo", fun.getNome_completo()));
            fun.setCidade(JOptionPane.showInputDialog(null, "Digite a cidade"));
            fun.setBairro(JOptionPane.showInputDialog(null, "Digite o bairro", fun.getBairro()));
            fun.setRua(JOptionPane.showInputDialog(null, "Digite o nome rua e numero da casa/ap", fun.getRua()));
            fun.setEmail(JOptionPane.showInputDialog(null, "Digite o Email", fun.getEmail()));
            fun.setCelular(JOptionPane.showInputDialog(null, "Digite o Celular", fun.getCelular()));

            pdao.atualizar(fun);
        
        } else {
            JOptionPane.showMessageDialog(null, "O aluno com o numero da matricula " + id + " não foi localizado.");//caso inserir uma matricula nao cadastrada
        } 
    }
    
    
    //metodo de procurar o aluno pela matricula 
    public static void procura() {

        int id = 0;
        AlunoGetSet fun = new AlunoGetSet();

        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o numero da matricula do aluno para localizar"));

        try {
            AlunoSQL x = new AlunoSQL();
            fun = x.procura(id);
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Dados do aluno com o numero da matricula indicado \n";

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrado !!");
        } else {
           
            //aparece quadro abaixo com o numero da matricula indicado
                msg = msg + "\nmatricula: "+ fun.getMatricula();
                msg = msg + "\nCpf: " + fun.getCpf();
                msg = msg + "\nNome_completo: " + fun.getNome_completo();
                msg = msg + "\nCidade: " + fun.getCidade();
                msg = msg + "\nBairro: " + fun.getBairro();
                msg = msg + "\nRua: " + fun.getRua();
                msg = msg + "\nEmail: " + fun.getEmail();
                msg = msg + "\nCelular: " + fun.getCelular();

                msg = msg + "\n___________________________________________________ \n";
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
}

