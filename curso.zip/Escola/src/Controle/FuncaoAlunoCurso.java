package Controle;


import ClassesGetSet.AlunoCursoGetSet;
import SQLDAOS.AlunoCursoSQL;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class FuncaoAlunoCurso{
    
    //metodo para listar
    public static void listar(ArrayList<AlunoCursoGetSet> Quadro) {
        try {
            AlunoCursoSQL x = new AlunoCursoSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de aluno e curso no quadro do aluno e curso \n";//vai listar o aluno e curso da tabela do BD
        int tamanho = Quadro.size();
        AlunoCursoGetSet fun = new AlunoCursoGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo no quadro
                msg = msg + "Posição: " + i;
                msg = msg + "\nMatricula: "+ Quadro.get(i).getMatricula();
                msg = msg + "\nCod_curso: "+ Quadro.get(i).getCod_curso();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
        
    //metodo para matricular aluno em um ou mais curso
     public static void inserir() {

        AlunoCursoGetSet fun = new AlunoCursoGetSet();
        
        //vai pedir parar que o usuario insira todos os requisitos abaixo
        fun.setMatricula(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo da matricula do aluno")));
        fun.setCod_curso(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo do curso")));
        
        AlunoCursoSQL pdao = new AlunoCursoSQL();
        
        pdao.inserir(fun);
    }
            
}
