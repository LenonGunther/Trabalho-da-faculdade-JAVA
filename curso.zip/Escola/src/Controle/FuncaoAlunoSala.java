package Controle;

import ClassesGetSet.AlunoSalaGetSet;
import SQLDAOS.AlunoSalaSQL;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class FuncaoAlunoSala {

    //metodo para listar
    public static void listar(ArrayList<AlunoSalaGetSet> Quadro) {
        try {
            AlunoSalaSQL x = new AlunoSalaSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de aluno e sala no quadro do aluno e sala \n";//vai listar o aluno e curso da tabela do BD
        int tamanho = Quadro.size();
        AlunoSalaGetSet fun = new AlunoSalaGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {

                //vai listar requisitos abaixo no quadro
                msg = msg + "Posição: " + i;
                msg = msg + "\nMatricula: " + Quadro.get(i).getMatricula();
                msg = msg + "\nSala_id: " + Quadro.get(i).getSala_id();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
    public static void inserir() {

        AlunoSalaGetSet fun = new AlunoSalaGetSet();

        //vai pedir parar que o usuario insira todos os requisitos abaixo
        fun.setMatricula(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo da matricula do aluno")));
        fun.setSala_id(Integer.parseInt(JOptionPane.showInputDialog("Digite o id da sala")));

        AlunoSalaSQL pdao = new AlunoSalaSQL();

        pdao.inserir(fun);
    }
}
