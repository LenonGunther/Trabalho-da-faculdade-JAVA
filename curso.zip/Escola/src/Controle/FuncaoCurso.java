package Controle;



import javax.swing.JOptionPane;
import java.util.ArrayList;
import SQLDAOS.CursoSQL;
import ClassesGetSet.CursoGetSet;

public class FuncaoCurso {
    
    //metodo para listar cursos do banco de dados
    public static void listar(ArrayList<CursoGetSet> Quadro) {
        try {
            CursoSQL x = new CursoSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de cursos no quadro do curso \n";//vai listar os curso na tabela curso
        int tamanho = Quadro.size();
        CursoGetSet fun = new CursoGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo
                msg = msg + "Posição: " + i;
                msg = msg + "\ncod_curso: "+ Quadro.get(i).getCod_curso();
                msg = msg + "\nnome_curso: " + Quadro.get(i).getNome_curso();
                msg = msg + "\ncarga_horaria: " + Quadro.get(i).getCarga_horaria();
                msg = msg + "\ndesc_curso: " + Quadro.get(i).getDesc_curso();
                msg = msg + "\ncod_funcionario: " + Quadro.get(i).getCod_funcionario();
                msg = msg + "\nsala_id: " + Quadro.get(i).getSala_id();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
    //metodo para inserir curso no banco de dados
    public static void Inserir() {

        CursoGetSet fun = new CursoGetSet();
        
        //vai pedir parar que o usuario insira todos os requisitos abaixo
        fun.setNome_curso(JOptionPane.showInputDialog("Digite o nome do curso"));
        fun.setCarga_horaria(JOptionPane.showInputDialog("Digite a carga horaria"));
        fun.setDesc_curso(JOptionPane.showInputDialog("Digite a descricao do curso"));
        fun.setCod_funcionario(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo do funcionario para alocar ele nesse curso")));
        fun.setSala_id(Integer.parseInt(JOptionPane.showInputDialog("Digite o Id da sala para alocar o curso numa sala")));
        
        CursoSQL pdao = new CursoSQL();
        
        pdao.inserir(fun);
    }
    
    
    //metodo para alterar alguma coluna do banco de dados do curso
    public static void atualizar() {
        CursoGetSet fun = new CursoGetSet();
        CursoSQL pdao = new CursoSQL();
        int id;
        
        id = Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo do curso para atualizar"));//vai pedir o codigo do curso para localizar e atualizar 
        fun = pdao.procura(id);
        if (fun != null) {
            
            //usuario vai poder atualizar qualquer requisito abaixo
            fun.setCod_curso(id);
            fun.setNome_curso(JOptionPane.showInputDialog(null, "Digite o Nome do curso", fun.getNome_curso()));
            fun.setCarga_horaria(JOptionPane.showInputDialog(null, "Digite a Carga horaria", fun.getCarga_horaria()));
            fun.setDesc_curso(JOptionPane.showInputDialog(null, "Digite a Descricao do curso", fun.getDesc_curso()));
            fun.setCod_funcionario(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo do funcionario para alocar ele nesse curso")));
            fun.setSala_id(Integer.parseInt(JOptionPane.showInputDialog("Digite o Id da sala para alocar o curso numa sala")));
        
        
            pdao.atualizar(fun);
        
        } else {
            JOptionPane.showMessageDialog(null, "O curso com o codigo " + id + " não foi localizado.");//aparece caso nao encontre o codigo do curso digitado
        } 
    }
        
    //metodo para procurar o curso pelo codigo do curso
    public static void procura() {

        int id = 0;
        CursoGetSet fun = new CursoGetSet();

        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o codigo do curso para localizar"));

        try {
            CursoSQL x = new CursoSQL();
            fun = x.procura(id);
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Dados do curso com o ID indicado \n";

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrado !!");//aparece caso nao encontrar o codigo do curso
        } else {
           
            //aparece requisitos a baixo no quadro com o codigo do curso indicado
                msg = msg + "\ncod_curso: "+ fun.getCod_curso();
                msg = msg + "\nNome_curso: " + fun.getNome_curso();
                msg = msg + "\nCarga_horaria: " + fun.getCarga_horaria();
                msg = msg + "\nDesc_curso: " + fun.getDesc_curso();
                msg = msg + "\ncod_funcionario: "+ fun.getCod_funcionario();
                msg = msg + "\nsala_id: "+ fun.getSala_id();
                
                msg = msg + "\n___________________________________________________ \n";
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
}

