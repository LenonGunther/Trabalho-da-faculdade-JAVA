package Controle;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import ClassesGetSet.ProfessorGetSet;
import SQLDAOS.ProfessorSQL;

public class FuncaoProfessor {
    
    //metodo de listar os professores do banco de dados
    public static void listar(ArrayList<ProfessorGetSet> Quadro) {
        try {
            ProfessorSQL x = new ProfessorSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de professores no quadro do professor \n";//vai listar os professores na tabela professor
        int tamanho = Quadro.size();
        ProfessorGetSet fun = new ProfessorGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo
                msg = msg + "Posição: " + i;
                msg = msg + "\nCod_funcionario: "+ Quadro.get(i).getCod_funcionario();
                msg = msg + "\nCpf: " + Quadro.get(i).getCpf();
                msg = msg + "\nNome_completo: " + Quadro.get(i).getNome_completo();
                msg = msg + "\nCidade: " + Quadro.get(i).getCidade();
                msg = msg + "\nBairro: " + Quadro.get(i).getBairro();
                msg = msg + "\nRua: " + Quadro.get(i).getRua();
                msg = msg + "\nEmail: " + Quadro.get(i).getEmail();
                msg = msg + "\nCelular: " + Quadro.get(i).getCelular();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
    //metodo para inserir um professor no banco de dados da tabela professor
    public static void Inserir() {

        ProfessorGetSet fun = new ProfessorGetSet();
        
        //vai pedir para que o usuario insira todos os requisitos abaixo
        fun.setCpf(JOptionPane.showInputDialog("Digite o Cpf"));
        fun.setNome_completo(JOptionPane.showInputDialog("Digite o Nome completo"));
        fun.setCidade(JOptionPane.showInputDialog("Digite a cidade"));
        fun.setBairro(JOptionPane.showInputDialog("Digite o Bairro"));
        fun.setRua(JOptionPane.showInputDialog("Digite o nome da rua e o numero da casa/ap"));
        fun.setEmail(JOptionPane.showInputDialog("Digite o Email"));
        fun.setCelular(JOptionPane.showInputDialog("Digite o Celular"));
        
        ProfessorSQL pdao = new ProfessorSQL();
        
        pdao.inserir(fun);
    }
    
    
    //metodo para alterar um professor especifico do banco de dados
    public static void atualizar() {
        ProfessorGetSet fun = new ProfessorGetSet();
        ProfessorSQL pdao = new ProfessorSQL();
        int id;
        
        id = Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo de funcionario do professor para alterar"));//vai pedir o codigo do funcionario para localizar e atualizar 
        fun = pdao.procura(id);
        if (fun != null) {
            //usuario vai poder atualizar qualquer requisito abaixo
            fun.setCod_funcionario(id);
            fun.setCpf(JOptionPane.showInputDialog(null, "Digite o Cpf", fun.getCpf()));
            fun.setNome_completo(JOptionPane.showInputDialog(null, "Digite o Nome_completo", fun.getNome_completo()));
            fun.setCidade(JOptionPane.showInputDialog(null, "Digite a cidade", fun.getCidade()));
            fun.setBairro(JOptionPane.showInputDialog(null, "Digite o bairro", fun.getBairro()));
            fun.setRua(JOptionPane.showInputDialog(null, "Digite o nome da rua e o numero da casa/ap", fun.getRua()));
            fun.setEmail(JOptionPane.showInputDialog(null, "Digite o Email", fun.getEmail()));
            fun.setCelular(JOptionPane.showInputDialog(null, "Digite o Celular", fun.getCelular()));

            pdao.atualizar(fun);
        
        } else {
            JOptionPane.showMessageDialog(null, "O professor com o codigo de funcionario " + id + " não foi localizado.");//aparece caso nao encontrar o codigo do funcionario indicado
        } 
    }
    
        
    //metodo para procurar um professor especifico pelo codigo do funcionaro
    public static void procura() {

        int id = 0;
        ProfessorGetSet fun = new ProfessorGetSet();

        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o codigo do funcionario do professor para localizar"));//usuario indica o codigo do funcionario

        try {
            ProfessorSQL x = new ProfessorSQL();
            fun = x.procura(id);
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Dados do professor com o cod_funcionario indicado \n";

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrado !!");//aparece caso nao encontrar o codigo do funcionario indicado pelo usuario
        } else {
           
            //aparece requisitos abaixo com o codigo especifico
                msg = msg + "\nCod_funcionario: "+ fun.getCod_funcionario();
                msg = msg + "\nCpf: " + fun.getCpf();
                msg = msg + "\nNome_completo: " + fun.getNome_completo();
                msg = msg + "\nCidade" + fun.getCidade();
                msg = msg + "\nBairro: " + fun.getBairro();
                msg = msg + "\nRua: " + fun.getRua();
                msg = msg + "\nEmail: " + fun.getEmail();
                msg = msg + "\nCelular: " + fun.getCelular();

                msg = msg + "\n___________________________________________________ \n";
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
}
