package Controle;

import ClassesGetSet.ProfessorCursoAluno;
import SQLDAOS.ProfessorCursoAlunoSQL;
import java.util.ArrayList;
import javax.swing.JOptionPane;



public class FuncaoProfessorCursoAluno {
    
    //metodo para listar CursoSala do banco de dados
    public static void listar(ArrayList<ProfessorCursoAluno> Quadro) {
        try {
            ProfessorCursoAlunoSQL x = new ProfessorCursoAlunoSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de cursos ativos no quadro\n";//vai listar os Cursos Salas da tabela CursoSala
        int tamanho = Quadro.size();
        ProfessorCursoAluno fun = new ProfessorCursoAluno();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo
                msg = msg + "Posição: " + i;
                msg = msg + "\nProfessor: "+ Quadro.get(i).getProfessor();
                msg = msg + "\nCurso: " + Quadro.get(i).getCurso();
                msg = msg + "\nAluno: " + Quadro.get(i).getAluno();
                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
}
