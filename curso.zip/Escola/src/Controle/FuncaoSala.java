package Controle;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import SQLDAOS.SalaSQL;
import ClassesGetSet.SalaGetSet;

public class FuncaoSala {
    
    //metodo para listar salas do banco de dados
    public static void listar(ArrayList<SalaGetSet> Quadro) {
        try {
            SalaSQL x = new SalaSQL();
            Quadro = x.listar();
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Lista de salas no quadro de salas \n";//vai listar as salas na tabela salas
        int tamanho = Quadro.size();
        SalaGetSet fun = new SalaGetSet();

        if (tamanho == 0) {
            JOptionPane.showMessageDialog(null, "Quadro Vazio !!");//aparece caso esteja vazio
        } else {
            for (int i = 0; i < tamanho; i++) {
                
                //vai listar requisitos abaixo
                msg = msg + "Posição: " + i;
                msg = msg + "\nsala_id: "+ Quadro.get(i).getSala_id();
                msg = msg + "\nNome: " + Quadro.get(i).getNome();
                msg = msg + "\nLocal: " + Quadro.get(i).getLocal();
                msg = msg + "\nCap_ total: " + Quadro.get(i).getCap_total();

                msg = msg + "\n___________________________________________________ \n";
            }
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
    //metodo para inserir uma sala no banco de dados
    public static void inserir() {

        SalaGetSet sal = new SalaGetSet();
        
        //vai pedir para que o usuario insira todos os requisitos abaixo
        sal.setNome(JOptionPane.showInputDialog("Digite o Nome"));
        sal.setLocal(JOptionPane.showInputDialog("Digite o local da sala"));
        sal.setCap_total(Integer.parseInt(JOptionPane.showInputDialog("Digite a capacidade total")));
        
        SalaSQL pdao = new SalaSQL();
        
        pdao.inserir(sal);
    }
    
    
    //metodo para alterar alguma informaçao especifica da tabela indicada pelo codigo da sala
    public static void atualizar() {
        SalaGetSet fun = new SalaGetSet();
        SalaSQL pdao = new SalaSQL();
        int id;
        
        id = Integer.parseInt(JOptionPane.showInputDialog("Digite o id da sala para atualizar"));//vai pedir o sala id para localizar e atualizar 
        fun = pdao.procura(id);
        if (fun != null) {
            //usuario vai poder atualizar qualquer requisito abaixo
            fun.setSala_id(id);
            fun.setNome(JOptionPane.showInputDialog(null, "Digite o Nome da sala", fun.getNome()));
            fun.setLocal(JOptionPane.showInputDialog(null, "Digite o local da sala", fun.getLocal()));
            fun.setCap_total(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a capacidade total", fun.getCap_total())));

            pdao.atualizar(fun);
        
        } else {
            JOptionPane.showMessageDialog(null, "A sala com o codigo " + id + " não foi localizado.");//caso nao encontrar o id da sala indicado pelo usuario
        } 
    }
        
    //metodo para procurar o id da sala especifico do usuario
    public static void procura() {

        int id = 0;
        SalaGetSet fun = new SalaGetSet();

        id = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o ID da sala para localizar"));//usuario digita para localizar

        try {
            SalaSQL x = new SalaSQL();
            fun = x.procura(id);
        } catch (Exception ex) {
            System.out.println("problema");
        }
        String msg = "Dados da sala com o ID indicado \n";

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "Não foi encontrado !!");//caso nao encontrar o id sala indicado pelo usuario
        } else {
       
            //aparece requisitos abaixo com o id da sala indicado
                msg = msg + "\nsala_id: "+ fun.getSala_id();
                msg = msg + "\nNome: " + fun.getNome();
                msg = msg + "\nlocal: " + fun.getLocal();
                msg = msg + "\nCap_total: " + fun.getCap_total();

                msg = msg + "\n___________________________________________________ \n";
            JOptionPane.showMessageDialog(null, msg);
        }
    }
    
}

