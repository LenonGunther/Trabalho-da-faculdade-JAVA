package PainelClasses;



import Controle.FuncaoAluno;
import ClassesGetSet.AlunoGetSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class alunoPainel {


    public static void alunoPainel () {
        ArrayList<AlunoGetSet> Quadro = new ArrayList<AlunoGetSet>();
        
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Painel Aluno"
                    + "\n\nOpçoes Aluno"                        
                    + "\nDigite:"                                            
                    + "\n'L' para Listar Alunos"                                                                
                    + "\n'I' para Inserir Aluno"                                                          
                    + "\n'A' para Atualizar Aluno pela matricula"                        
                    + "\n\n'0' para Voltar").charAt(0));
            
            switch (op) {
                case 'L':
                case 'l':
                    FuncaoAluno.listar(Quadro);//Lista Alunos
                    break;
                case 'I':
                case 'i':
                    FuncaoAluno.inserir();//Insere Alunos
                    break;
                case 'A':
                case 'a':
                    FuncaoAluno.atualizar();//Altera Aluno
                    break;
            }
        }  while (op != '0');//volta pro menu principal
    }
           
 }