package PainelClasses;



import ClassesGetSet.AlunoCursoGetSet;
import Controle.FuncaoAlunoCurso;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class alunocursoPainel {


    public static void alunocursoPainel() {
        ArrayList<AlunoCursoGetSet> Quadro = new ArrayList<AlunoCursoGetSet>();
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Painel aluno e curso"
                    + "\n\nEscolha:"
                    + "\n'I' para Inserir o Aluno num curso"
                    + "\n'L' Para Listar aluno e curso"
                    + "\n\n'0' para voltar").charAt(0));
            
            switch (op) {
                case 'I':
                case 'i':
                    FuncaoAlunoCurso.inserir();//Insere Aluno no curso
                    break;
                case 'L':
                case 'l':
                    FuncaoAlunoCurso.listar(Quadro);//leva o usuario de uma classse para outra
                    break;
                    
            }
        }  while (op != '0');
        
    }
    
}
