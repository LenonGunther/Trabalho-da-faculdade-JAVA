package PainelClasses;


import ClassesGetSet.AlunoSalaGetSet;
import Controle.FuncaoAlunoSala;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class alunosalaPainel {


    public static void alunosalaPainel() {
        ArrayList<AlunoSalaGetSet> Quadro = new ArrayList<AlunoSalaGetSet>();
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Painel aluno e sala"
                    + "\n\nEscolha:"
                    + "\n'I' para Inserir o Aluno numa sala"
                    + "\n'L' para Listar aluno e sala"
                    + "\n\n'0' para voltar").charAt(0));
            
            switch (op) {
                case 'I':
                case 'i':
                    FuncaoAlunoSala.inserir();
                    break;
                case 'L':
                case 'l':
                    FuncaoAlunoSala.listar(Quadro);
                    break;    
            }
        }  while (op != '0');
        
    }
    
}
