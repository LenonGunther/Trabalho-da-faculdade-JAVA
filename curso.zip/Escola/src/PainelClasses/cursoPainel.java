package PainelClasses;


import Controle.FuncaoCurso;
import ClassesGetSet.CursoGetSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class cursoPainel {


    public static void cursoPainel () {
        ArrayList<CursoGetSet> Quadro = new ArrayList<CursoGetSet>();
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Painel Curso "                       
                    + "\nDigite:"                                            
                    + "\n'L' para Listar Cursos"                                                                
                    + "\n'I' para Inserir Curso"                            
                    + "\n'A' para Atualizar Curso pelo codigo"                        
                    + "\n\n'0' para Voltar").charAt(0));
            
            switch (op) {
                //Area menu professor abaixo
                case 'L':
                case 'l':
                    FuncaoCurso.listar(Quadro);//Lista Cursos
                    break;
                case 'I':
                case 'i':
                    FuncaoCurso.Inserir();//Insere Cursos 
                    break;
                case 'A':
                case 'a':
                    FuncaoCurso.atualizar();//Altera Curso
                    break;

            }
        }  while (op != '0');//volta pro menu principal
    }
           
 }
