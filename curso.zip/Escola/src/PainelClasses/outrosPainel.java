package PainelClasses;


import ClassesGetSet.ProfessorCursoAluno;
import Controle.FuncaoProfessorCursoAluno;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class outrosPainel {


    public static void outrosPainel () {
         ArrayList<ProfessorCursoAluno> Quadro = new ArrayList<ProfessorCursoAluno>();
         
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo"                     
                    + "\n\nEscolha:"                                                                                                          
                    + "\n'1' para ver Painel aluno e curso"
                    + "\n'2' para ver Painel aluno e sala"                              
                    + "\n'3' para Listar Professores, cursos e Alunos Ativos"                                                 
                    + "\n\n'0' para Voltar").charAt(0));
            
            switch (op) {

                case '1':
                    alunocursoPainel.alunocursoPainel();//leva para outro painel
                    break;
                case '2':
                    alunosalaPainel.alunosalaPainel();//leva para outro painel
                    break;
                case '3':
                    FuncaoProfessorCursoAluno.listar(Quadro);//lista cursos ativos
                    break;  

            }
        }  while (op != '0');//volta pro menu principal
    }
           
 }
