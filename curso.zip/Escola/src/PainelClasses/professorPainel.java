package PainelClasses;


import Controle.FuncaoProfessor;
import ClassesGetSet.ProfessorGetSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class professorPainel {


    public static void professorPainel () {
        ArrayList<ProfessorGetSet> Quadro = new ArrayList<ProfessorGetSet>();
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Professor"                       
                    + "\nDigite:"                                            
                    + "\n'L' para Listar Professores"                                                                
                    + "\n'I' para Inserir Professor"                                                       
                    + "\n'A' para Atualizar Professor pelo codigo"                        
                    + "\n\n'0' para Voltar").charAt(0));
            
            switch (op) {
                case 'L':
                case 'l':
                    FuncaoProfessor.listar(Quadro);//Lista professores
                    break;
                case 'I':
                case 'i':
                    FuncaoProfessor.Inserir();//Insere professor
                    break;
                case 'A':
                case 'a':
                    FuncaoProfessor.atualizar();//Altera Professores
                    break;
                    
            }
        }  while (op != '0');//volta pro menu principal
    }
           
 }
        
