package PainelClasses;


import Controle.FuncaoSala;
import ClassesGetSet.SalaGetSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class salaPainel {


    public static void salaPainel () {
        ArrayList<SalaGetSet> Quadro = new ArrayList<SalaGetSet>();
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao Painel Sala"                       
                    + "\nDigite:"                                            
                    + "\n'L' para Listar Salas"                                                                
                    + "\n'I' para Inserir Sala"                            
                    + "\n'A' para Atualizar Sala pelo id"                       
                    + "\n\n'0' para Voltar").charAt(0));
            
            switch (op) {
                case 'L':
                case 'l':
                    FuncaoSala.listar(Quadro);//Lista Salas
                    break;
                case 'I':
                case 'i':
                    FuncaoSala.inserir();//Insere Salas
                    break;
                case 'A':
                case 'a':
                    FuncaoSala.atualizar();//Altera Sala
                    break;
                         
            }
        }  while (op != '0');//volta pro menu principal
    }
           
 }
