package principal;

import javax.swing.JOptionPane;
import PainelClasses.professorPainel;
import PainelClasses.alunoPainel;
import PainelClasses.cursoPainel;
import PainelClasses.outrosPainel;
import PainelClasses.salaPainel;

public class Principal {


    public static void main(String[] args) {
        
        char op = ' ';          
        
        do {
                   
            op = (JOptionPane.showInputDialog(null, "Bem Vindo ao MENU"
                    + "\n\nEscolha:"
                    + "\n'A' para Painel Aluno"
                    + "\n'P' para Painel Professor"
                    + "\n'C' para Painel Curso"
                    + "\n'S' para Painel Sala"
                    + "\n'F' para Outras funcoes"
                    + "\n\n'0' para Encerrar o programa").charAt(0));
            
            switch (op) {
                case 'A':
                case 'a':
                    alunoPainel.alunoPainel();//Aparece Principal.professorPainel leva o usuario de uma classe para outra
                    break;
                case 'P':
                case 'p':
                    professorPainel.professorPainel();//Aparece Principal.alunoPainel leva o usuario de um classe para outra
                 break;                 
                case 'C':
                case 'c':
                    cursoPainel.cursoPainel();//Aparece Principal.cursoPainel leva o usuario de uma classe para outra
                 break;                 
                case 'S':
                case 's':
                    salaPainel.salaPainel();//Aparece Principal.salaPainel leva o usuario de uma classse para outra
                  break;
                case 'F':
                case 'f':
                    outrosPainel.outrosPainel();//Aparece Principal.outrosPainel leva o usuario de uma classse para outra
                    break;
                    
            }
        }  while (op != '0');
        
    }

    
}
