package SQLDAOS;


import ClassesGetSet.AlunoCursoGetSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;

public class AlunoCursoSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados da tabela
    public AlunoCursoSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso nao der sucesso com a conexao ao banco
        }
    }
    
    //arraylist para listar quadro da tabela
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT * FROM alunocurso ";//lista informações
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            //busca gets e sets da classe
            while (rs.next()) {
                int matricula = rs.getInt("matricula");
                 int cod_curso = rs.getInt("cod_curso");
                
                 
                Quadro.add(new AlunoCursoGetSet(matricula, cod_curso));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar aluno e curso " + sqle);//aparece mensagem de erro caso nao consiga listar
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
    
    //metodo de matricular aluno em um curso
    public void inserir(AlunoCursoGetSet fun) {

        PreparedStatement ps = null;
        Connection connL = null;

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto aluno não pode ser nulo.");
        }
        try {
            String SQL = "INSERT INTO alunocurso (matricula, cod_curso) "
                    + "values (?,?)";//faz função de matricular aluno em um curso
 
            connL = this.conn;
            ps = connL.prepareStatement(SQL);    
            ps.setString(1, Integer.toString(fun.getMatricula()));
            ps.setString(2, Integer.toString(fun.getCod_curso()));
          
            ps.executeUpdate();//vai executar update na tabela

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir um novo aluno " + sqle);//aparece mensagem caso não consiga matricular aluno no curso
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
    
}
