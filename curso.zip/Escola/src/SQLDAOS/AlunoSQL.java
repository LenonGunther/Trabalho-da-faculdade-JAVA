
package SQLDAOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;
import ClassesGetSet.AlunoGetSet;

public class AlunoSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados da tabela aluno
    public AlunoSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso nao der sucesso com a conexao ao banco
        }
    }
    
    //arraylist para listar quadro da tabela
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT * FROM aluno";//lista todas informações da tabela aluno
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            //busca gets e sets da classe aluno
            while (rs.next()) {
                int matricula = rs.getInt("matricula");
                String cpf = rs.getString("cpf");                
                String nome_completo = rs.getString("nome_completo");
                String cidade = rs.getString("cidade");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String email = rs.getString("email");
                String celular = rs.getString("celular");
                
                
                Quadro.add(new AlunoGetSet(matricula, cpf, nome_completo, cidade, bairro, rua, email, celular));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar aluno " + sqle);//aparece mensagem de erro caso nao consiga lista o banco aluno
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
    
    //metodo de inserir
    public void inserir(AlunoGetSet doom) {

        PreparedStatement ps = null;
        Connection connL = null;

        if (doom == null) {
            JOptionPane.showMessageDialog(null, "O objeto aluno não pode ser nulo.");
        }
        try {
            String SQL = "INSERT INTO aluno (cpf, nome_completo, cidade, bairro, rua, email, celular) "
                    + "values (?,?,?,?,?,?,?)";//faz função de inserir professor na tabela professor do banco de dados
 
            connL = this.conn;
            ps = connL.prepareStatement(SQL);    
            ps.setString(1, doom.getCpf());           
            ps.setString(2, doom.getNome_completo());
            ps.setString(3, doom.getCidade());
            ps.setString(4, doom.getBairro());
            ps.setString(5, doom.getRua());
            ps.setString(6, doom.getEmail());
            ps.setString(7, doom.getCelular());
          
            ps.executeUpdate();//vai executar update na tabela

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir um novo aluno " + sqle);//aparece mensagem caso não consiga insirir um novo aluno
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
    
    //metodo de alterar alguma informacao do aluno especificar
    public void atualizar(AlunoGetSet fun) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto aluno não pode ser nulo.");//aparece mensagem informando que não pode ser nulo
        }

        try {
            String SQL = "UPDATE aluno set cpf=?, nome_completo=?, cidade=?, bairro=?, rua=?, email=?, celular=? WHERE matricula=?";//vai pedir para o usuario alterar e executa comando
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            
            ps.setString(1, fun.getCpf());           
            ps.setString(2, fun.getNome_completo());
            ps.setString(3, fun.getCidade());
            ps.setString(4, fun.getBairro());
            ps.setString(5, fun.getRua());
            ps.setString(6, fun.getEmail());
            ps.setString(7, fun.getCelular());
            ps.setString(8, Integer.toString(fun.getMatricula()));
            
            ps.executeUpdate();//vai executar update na tabela

       } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao editar aluno " + sqle);//aparece mensagem caso n consiga editar o aluno
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
    
    
    //metodo de procurar um aluno especifico pela matricula
    public AlunoGetSet procura(int id) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        AlunoGetSet a = new AlunoGetSet();
        a = null;

        try {
            String SQL = "SELECT * FROM aluno WHERE matricula = ?";//procura o aluno na tabela pela matricula
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {
                
                int matricula = rs.getInt("matricula");
                String cpf = rs.getString("cpf");                
                String nome_completo = rs.getString("nome_completo");
                String cidade = rs.getString("cidade");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String email = rs.getString("email");
                String celular = rs.getString("celular");
                
                a = new AlunoGetSet (matricula, cpf, nome_completo, cidade, bairro, rua, email, celular);

            }

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar aluno " + sqle); //aparece mensagem caso n consiga listar aluno especifico
        } finally {
            
        }

        return a;
    }    
    
}
