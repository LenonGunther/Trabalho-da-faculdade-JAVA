package SQLDAOS;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;
import ClassesGetSet.CursoGetSet;


public class CursoSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados da tabela curso
    public CursoSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso nao der sucesso com a conexao ao banco
        }
    }
    
    //metodo arraylist listar para listar todos os cursos do banco de dados
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT * FROM curso";//lista todos os cursos do banco de dados
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            //busca get e set da classe curso
            while (rs.next()) {
                int cod_curso = rs.getInt("cod_curso");             
                String nome_curso = rs.getString("nome_curso");
                String carga_horaria = rs.getString("carga_horaria");
                String desc_curso = rs.getString("desc_curso");
                int Cod_funcionario = rs.getInt("Cod_funcionario");
                int sala_id = rs.getInt("sala_id");

                Quadro.add(new CursoGetSet(cod_curso, nome_curso, carga_horaria, desc_curso, Cod_funcionario, sala_id));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar curso " + sqle);//aparece caso n consiga listar cursos + mensagem de erro
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
    
    //metodo de inserir curso no banco e alocar um funcionario no curso
    public void inserir(CursoGetSet fun) {

        PreparedStatement ps = null;
        Connection connL = null;

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto curso não pode ser nulo.");
        }
        try {
            String SQL = "INSERT INTO curso (nome_curso, carga_horaria, desc_curso, cod_funcionario, sala_id) "
                    + "values (?,?,?,?,?)";//insere curso na tabela curso 
 
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setString(1, fun.getNome_curso());
            ps.setString(2, fun.getCarga_horaria());
            ps.setString(3, fun.getDesc_curso());
            ps.setInt(4, fun.getCod_funcionario());
            ps.setInt(5, fun.getSala_id());

            ps.executeUpdate();

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir um curso " + sqle);//aparece caso n consiga inserir um curso + mensagem de erro
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
         
    //metodo de alterar curso do banco de dados
    public void atualizar(CursoGetSet fun) {
         PreparedStatement ps = null;
        Connection connL = null;
        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto cursos não pode ser nulo.");
        }

        try {
            String SQL = "UPDATE curso set nome_curso=?, carga_horaria=?, desc_curso=?, cod_funcionario=?, sala_id=? WHERE cod_curso=?";//altera algo na tabela pelo codigo do curso selecionado
            connL = this.conn;
            ps = connL.prepareStatement(SQL);           
            ps.setString(1, fun.getNome_curso());
            ps.setString(2, fun.getCarga_horaria());
            ps.setString(3, fun.getDesc_curso());
            ps.setString(4, Integer.toString(fun.getCod_funcionario()));
            ps.setString(5, Integer.toString(fun.getSala_id()));
            ps.setString(6, Integer.toString(fun.getCod_curso()));
            
            ps.executeUpdate();

       } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao editar curso " + sqle);//aparece mensagem de erro se nao alterar curso
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
    
    //metodo de procurar um curso especifico 
    public CursoGetSet procura(int Id) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        CursoGetSet fun = new CursoGetSet();
        fun = null;

        try {
            String SQL = "SELECT * FROM curso WHERE cod_curso = ?";//busca o curso pelo codigo do curso
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, Id);
            rs = ps.executeQuery();

            while (rs.next()) {
                int cod_curso = rs.getInt("cod_curso");             
                String nome_curso = rs.getString("nome_curso");
                String carga_horaria = rs.getString("carga_horaria");
                String desc_curso = rs.getString("desc_curso");
                int Cod_funcionario = rs.getInt("cod_funcionario");
                int sala_id = rs.getInt("sala_id");

                fun = new CursoGetSet(cod_curso, nome_curso, carga_horaria, desc_curso, Cod_funcionario, sala_id);

            }

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar cursos " + sqle);//aparece mensagem de erro se nao listar curso
        } finally {
            
        }

        return fun;
    }    
    
}

