 package SQLDAOS;


import ClassesGetSet.ProfessorCursoAluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;


public class ProfessorCursoAlunoSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados
    public ProfessorCursoAlunoSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso nao der sucesso com a conexao ao banco
        }
    }
    
    //metodo arraylist listar para listar o professor curso e aluno ativos
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT professor.nome_completo as professor, curso.nome_curso as curso, aluno.nome_completo as aluno "
                    + "FROM professor, curso, aluno, alunocurso "
                    + "WHERE professor.cod_funcionario = curso.cod_funcionario "
                    + "AND curso.cod_curso = alunocurso.cod_curso "
                    + "AND alunocurso.matricula = aluno.matricula";//lista todos os cursos do banco de dados
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            //busca get e set da classe curso
            while (rs.next()) {            
                String professor = rs.getString("professor");
                String curso = rs.getString("curso");
                String aluno = rs.getString("aluno");

                Quadro.add(new ProfessorCursoAluno(professor, curso,  aluno));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar curso " + sqle);//aparece caso n consiga listar cursos + mensagem de erro
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
}
         
