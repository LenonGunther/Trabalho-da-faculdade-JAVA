package SQLDAOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;
import ClassesGetSet.ProfessorGetSet;

public class ProfessorSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados da tabela professor
    public ProfessorSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso n der sucesso com a conexao ao banco
        }
    }
    
    //metodo arraylist listar para listar professores do banco de dados
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT * FROM professor";//lista todas informações da tabela professor
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            //busca get e set da classe professor
            while (rs.next()) {
                int cod_funcionario = rs.getInt("cod_funcionario");
                String cpf = rs.getString("cpf");                
                String nome_completo = rs.getString("nome_completo");
                String cidade = rs.getString("cidade");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String email = rs.getString("email");
                String celular = rs.getString("celular");
                
                
                Quadro.add(new ProfessorGetSet(cod_funcionario, cpf, nome_completo, cidade, bairro, rua, email, celular));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar professor " + sqle);//aparece mensagem de erro caso nao consiga listar o banco professores
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
    
    //metodo de inserir professor no banco de dados
    public void inserir(ProfessorGetSet fun) {

        PreparedStatement ps = null;
        Connection connL = null;

        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto professor não pode ser nulo.");
        }
        try {
            String SQL = "INSERT INTO professor (cpf, nome_completo, cidade, bairro, rua, email, celular) "
                    + "values (?,?,?,?,?,?,?)";//faz função de inserir professor na tabela professor do banco de dados
 
            connL = this.conn;
            ps = connL.prepareStatement(SQL);    
            ps.setString(1, fun.getCpf());           
            ps.setString(2, fun.getNome_completo());
            ps.setString(3, fun.getCidade());
            ps.setString(4, fun.getBairro());
            ps.setString(5, fun.getRua());
            ps.setString(6, fun.getEmail());
            ps.setString(7, fun.getCelular());
           

          
            ps.executeUpdate();//vai executar update na tabela

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir um novo professor " + sqle);//aparece mensagem caso não consiga insirir um novo professor
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
     
    //metodo de alterar professor indicado pelo usuario no banco de dados
    public void atualizar(ProfessorGetSet fun) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto professor não pode ser nulo.");//aparece mensagem informando que não pode ser nulo
        }

        try {
            String SQL = "UPDATE professor set cpf=?, nome_completo=?, cidade=?, bairro=?, rua=?, email=?, celular=? WHERE cod_funcionario=?";//comando sql para alterar e executar informação para o banco de dados
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            
            ps.setString(1, fun.getCpf());           
            ps.setString(2, fun.getNome_completo());
            ps.setString(3, fun.getCidade());
            ps.setString(4, fun.getBairro());
            ps.setString(5, fun.getRua());
            ps.setString(6, fun.getEmail());
            ps.setString(7, fun.getCelular());
            ps.setString(8, Integer.toString(fun.getCod_funcionario()));
            
            ps.executeUpdate();//vai executar update na tabela

       } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao editar professor " + sqle);//aparece mensagem caso nao consiga editar o professor
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
    
    //metodo para procurar o professor especifico do banco de dados
    public ProfessorGetSet procura(int id) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ProfessorGetSet fun = new ProfessorGetSet();
        fun = null;

        try {
            String SQL = "SELECT * FROM professor WHERE cod_funcionario = ?";//procura o professor na tabela pelo codigo do funcionario
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {
                
                int cod_funcionario = rs.getInt("cod_funcionario");
                String cpf = rs.getString("cpf");                
                String nome_completo = rs.getString("nome_completo");
                String cidade =rs.getString("cidade");
                String bairro = rs.getString("bairro");
                String rua = rs.getString("rua");
                String email = rs.getString("email");
                String celular = rs.getString("celular");
                
                fun = new ProfessorGetSet (cod_funcionario, cpf, nome_completo, cidade, bairro, rua, email, celular);

            }

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar professor " + sqle); //aparece mensagem caso nao consiga listar tabela indicado peloo usuario
        } finally {
            
        }

        return fun;
    }    
    
}

