package SQLDAOS;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Util.BancoDadosConexao;
import ClassesGetSet.SalaGetSet;

public class SalaSQL {
    
    private Connection conn;

    //aparece caso nao conseguir conectar com o banco de dados da tabela aluno
    public SalaSQL() {
        try {
            this.conn = BancoDadosConexao.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro de conexão: " + ":\n" + e.getMessage());
            //Aparece mensagem de erro caso nao der sucesso com a conexao ao banco
        }
    }
    
    //metodo para listar salas do banco de dados
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Quadro = new ArrayList();

        try {
            String SQL = "SELECT * FROM sala";//seleciona todas salas do banco de dados
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int sala_id = rs.getInt("sala_id");
                String nome = rs.getString("nome");                
                String local = rs.getString("local");
                int cap_total = rs.getInt("cap_total");
                
                Quadro.add(new SalaGetSet(sala_id, nome, local, cap_total));
            }
        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar salas " + sqle);//aparece caso nao listar salas ou der erro
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
        return Quadro;
    }
    
    //metodo de inserir salas no banco de dados
    public void inserir(SalaGetSet sal) {

        PreparedStatement ps = null;
        Connection connL = null;

        if (sal == null) {
            JOptionPane.showMessageDialog(null, "O objeto sala não pode ser nulo.");
        }
        try {
            String SQL = "INSERT INTO sala (nome, local, cap_total) "
                    + "values (?,?,?)";//insere sala com informaçoes no banco de dados
 
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setString(1, sal.getNome());           
            ps.setString(2, sal.getLocal());
            ps.setInt(3, sal.getCap_total());
            
            ps.executeUpdate();
            

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir uma nova sala " + sqle);//aparece caso nao inserir sala no banco
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
             
    //metodo de atualizar sala no banco de dados
    public void atualizar(SalaGetSet fun) {
         PreparedStatement ps = null;
        Connection connL = null;
        if (fun == null) {
            JOptionPane.showMessageDialog(null, "O objeto sala não pode ser nulo.");
        }

        try {
            String SQL = "UPDATE sala set nome=?, local=?, cap_total=? WHERE sala_id=?";//executa alteração na tabela sala indicada pelo usuario
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            
            ps.setString(1, fun.getNome());            
            ps.setString(2, fun.getLocal());
            ps.setInt(3, fun.getCap_total());
            ps.setString(4, Integer.toString(fun.getSala_id()));
            ps.executeUpdate();

       } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao editar sala " + sqle);//aparece caso nao encontrar o editar sala
        } finally {
            BancoDadosConexao.close(connL, ps);
        }
    }
        
    //metodo de procurar uma sala especifica no banco de dados
    public SalaGetSet procura(int Id) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        SalaGetSet fun = new SalaGetSet();
        fun = null;

        try {
            String SQL = "SELECT * FROM sala WHERE sala_id = ?";//seleciona sala do banco de dados indicado pelo usuario
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, Id);
            rs = ps.executeQuery();

            while (rs.next()) {
                int sala_id = rs.getInt("sala_id");
                String nome = rs.getString("nome");                
                String local = rs.getString("local");
                int cap_total = rs.getInt("cap_total");
  
                fun = new SalaGetSet(sala_id, nome, local, cap_total);

            }

        } catch (SQLException sqle) {
            JOptionPane.showMessageDialog(null, "Erro ao listar sala " + sqle);//aparece caso n encontrar ou listar sala indicada
        } finally {
            
        }

        return fun;
    }    
    
}
