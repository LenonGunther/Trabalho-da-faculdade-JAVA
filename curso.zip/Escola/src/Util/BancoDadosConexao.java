package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BancoDadosConexao {
  
    public static Connection getConnection() {
    	Connection conexao = null;
    	try
    	{
	    	Class.forName("com.mysql.jdbc.Driver"); 
	    	System.out.println("Driver carregado");//aparece mensagem de carregado caso tenha sido um sucesso
    	}
    	catch(ClassNotFoundException e)
    	{
    		System.out.println("Erro ao carregar o driver");//aparece mensagem erro caso nao tenha sido um sucesso
    	}

       try{
           conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/curso", "root", "");//comando de conexao com o phpmyadmin
           System.out.println("Conexão ok");//aparece mensagem de OK caso tenha sido um sucesso a conexao
       }catch(Exception e){
          System.out.println(e.getMessage());
          conexao = null;
       }
       
       return conexao;
       
   }

   public static void close(Connection conn, Statement stmt, ResultSet rs) {
       try{
           if (rs != null) rs.close();
           if (stmt != null) stmt.close();
           if (conn != null) conn.close();
       }catch(Exception e){
    	   System.out.println(e.getMessage());
       }
   }
   
   public static void close(Connection conn, Statement stmt) {
       try{
           if (stmt != null) stmt.close();
           if (conn != null) conn.close();
       }catch(Exception e){
    	   System.out.println(e.getMessage());
       }
   }

}